module.exports = [
  {
    location: "광주광역시 광천동 932 번지 신세계 백화점 1층 서구 광주광역시 KR",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "서구",
      place: "신세계 백화점 1층 서구 광주광역시 KR"
  },
    name: "스타벅스 신세계광주점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1587156,
        longitude: 126.8797941
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목| 9:30 - 21:00'
        
      },
      {
         
         content: '토| 9:30 - 22:00'
      },
      {  
         content: '금, 일 | 9:30 - 21:30'
      },
      {
         
        title: '전화번호',
        content: '062-360-1137'
      }
      
    ] 
  },  
 {
    location: "광주광역시 서구 화정1동 죽봉대로 61 패션스트리트 B01",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "서구",
      place: "패션스트리트 B01"
  },
    name: "스타벅스 신세계광주패션몰점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1559512,
        longitude: 126.8698522
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금, 토, 일|10:30~ 21:00'
        
     
      },
      {
      
        title: '전화번호',
        content: '062-352-8437'
      }
      
    ] 
  }, 
   {
    location: "광주광역시 서구 화정동 상무대로1080번길",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "서구",
      place: "상무대로1080번길"
  },
    name: "스타벅스 광주화정DT점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1559512,
        longitude: 126.8698826
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금| 7:00 - 23:00'
        
      },
      {
         
         content: '토, 일| 8:00 - 23:00'
        
      },
      {
      
         
        title: '전화번호',
        content: '062-362-3539'
      }
        
    ] 
  },  
 {
    location: "광주광역시 서구 화정1동 죽봉대로 33",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "서구",
      place: "죽봉대로 33"
  },
    name: "스타벅스 광주신세계DT점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1532498,
        longitude: 126.8722849
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금, 토, 일|7:00~ 22:00'
        
     
      },
         
    ] 
  }, 
   {
    location: "광주광역시 동구 충장로3가 충장로 65",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "동구",
      place: "충장로 65"
  },
    name: "스타벅스 광주충장로점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1485284,
        longitude: 126.8960833
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금| 8:00 - 22:00'
        
      },
      {
         
         content: '토, 일| 9:00 - 22:00'
        
      },
      {
      
         
        title: '전화번호',
        content: '062-224-8344'
      }
         
    ] 
  }, 
   {
    location: "광주광역시 남구 방림동 대남대로 67",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "남구",
      place: "남구 방림동 대남대로 67"
  },
    name: "스타벅스 광주화정DT점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1336796,
        longitude: 126.8987338
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금, 토, 일| 7:00 - 23:00'
        
      },
      {
      
         
        title: '전화번호',
        content: '062-654-3277'
      }
         
    ] 
  }, 
   {
    location: "광주광역시 남구 봉선2동 제석로 104 에이치알 팰리스 202동 B102호",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "남구",
      place: "에이치알 팰리스 202동 B102호"
  },
    name: "스타벅스 광주봉선로점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1296437,
        longitude: 126.902287
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 일| 8:00 - 23:00'
        
      },
      {
         
         content: '금, 토| 8:00 - 24:00'
        
      },
      {
      
         
        title: '전화번호',
        content: '062-653-3591'
      }
         
    ] 
  }, 
   {
    location: "광주광역시 북구 중흥동 276-1",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "북구",
      place: "북구 중흥동 276-1"
  },
    name: "스타벅스 광주북구청점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1676549,
        longitude: 126.8771483
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금, 토, 일| 8:00 - 23:00'
        
     
      },
      {
      
         
        title: '전화번호',
        content: '062-251-3202'
      }
         
    ] 
  }, 
   {
    location: "광주광역시 북구 용봉동 저불로 45",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "북구",
      place: "저불로 45"
  },
    name: "스타벅스 광주용봉점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1676549,
        longitude: 126.8771483
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금| 7:00 - 23:00'
        
      },
      {
         
         content: '토, 일| 8:00 - 23:00'
        
      },
      {
      
         
        title: '전화번호',
        content: '062-523-8471'
      }
         
    ] 
  }, 
   {
    location: "광주광역시 광산구 비아동 임방울대로 487",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "광산구",
      place: "임방울대로 487"
  },
    name: "스타벅스 광주수완DT점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1651146,
        longitude: 126.8429538
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금| 7:00 - 23:00'
        
      },
      {
         
         content: '토, 일| 8:00 - 23:00'
        
      },
      {
      
         
        title: '전화번호',
        content: '062-952-3291'
      }
         
    ] 
  }, 
   {
    location: "광주광역시 서구 치평동 1216 눈높이상무센터 1층",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "서구",
      place: "눈높이상무센터 1층"
  },
    name: "스타벅스 광주상무대교점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1582965,
        longitude: 126.8224893
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금| 7:00 - 23:00'
        
      },
      {
         
         content: '토, 일| 8:00 - 23:00'
        
      },
      {
      
         
        title: '전화번호',
        content: '062-372-8684'
      }
         
    ] 
  }, 
   {
    location: "광주광역시 서구 치평동 운천로 253",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "서구",
      place: "운천로 253"
  },
    name: "스타벅스 광주상무시민로점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1582965,
        longitude: 126.8224893
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목| 8:00 - 23:00'
        
      },
      {
         
         content: '금| 8:00 - 24:00'
        
      },
      {
        
         content: '토| 9:00 - 24:00'
        
      },
      {
        content: '일| 9:00 - 23:00'
        
      },
      { 
        title: '전화번호',
        content: '062-371-3264'
      }
         
    ] 
  }, 
   {
    location: "광주광역시 서구 치평동 상무중앙로 75",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "서구",
      place: "상무중앙로 75"
  },
    name: "스타벅스 광주상무점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1582965,
        longitude: 126.8224893
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금| 7:00 - 22:00'
        
      },
      {
         
         content: '토, 일| 9:00 - 22:00'
        
      },
      {
      
         
        title: '전화번호',
        content: '062-385-8040'
      }
         
    ] 
  }, 
   {
    location: "광주광역시 서구 치평동 상무자유로 173 1층",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "서구",
      place: "상무자유로 173 1층"
  },
    name: "스타벅스 상무치평점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1582965,
        longitude: 126.8224893
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금| 7:00 - 22:00'
        
      },
      {
         
         content: '토| 8:00 - 22:00'
        
      },
      {
         content: '일| 9:00 - 22:00'
        
      },
      { 
         
        title: '전화번호',
        content: '062-362-3539'
      }
         
    ] 
  }, 
   {
    location: "광주광역시 서구 치평동 상무중앙로 46",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "서구",
      place: "상무중앙로 46"
  },
    name: "스타벅스 광주상무중앙로점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1511104,
        longitude: 126.8487521
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금, 토| 8:00 - 23:00'
        
      },
      {
        
         content: '일| 9:00 - 23:00'
      

      },
      { 
         
        title: '전화번호',
        content: '062-375-3326'
      }
         
    ] 
  },
  {
    location: "광주광역시 광산구 송정동 상무대로205번길 6",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "광산구",
      place: "상무대로205번길 6"
  },
    name: "스타벅스 광주송정역점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1362995,
        longitude: 126.7866747
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금, 토, 일| 7:00 - 23:00'
        
      },
      {
       
        title: '전화번호',
        content: '062-942-3360'
      }
         
    ] 
  }, 
   {
    location: "광주광역시 서구 치평동 상무중앙로 7",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "서구",
      place: "상무중앙로 7"
  },
    name: "스타벅스 상무역점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1496325,
        longitude: 126.8481659
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금| 7:00 - 23:00'
        
      },
      {
         
         content: '토, 일| 8:00 - 23:00'
        
      },
      {
      
         
        title: '전화번호',
        content: '062-381-8393'
      }
         
    ] 
  }, 
   {
    location: "광주광역시 서구 쌍촌동 운천로109번길 1",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "서구",
      place: "운천로109번길 1"
  },
    name: "스타벅스 광주금호DT점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1641598,
        longitude: 126.8405898
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금| 7:00 - 23:00'
        
      },
      {
         
       
         
        title: '전화번호',
        content: '062-381-7905'
      }
         
    ] 
  }, 
   {
    location: "광주광역시 서구 풍암동 풍암2로 8",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "서구",
      place: "풍암2로 8"
  },
    name: "스타벅스 광주풍암점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1416646,
        longitude: 126.8699008
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금, 토,일| 7:00 - 23:00'
      
        
      },
      {
      
         
        title: '전화번호',
        content: '062-674-3203'
      }
         
    ] 
  }, 
   {
    location: "광주광역시 광산구 우산동 1585-5",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "광산구",
      place: "1585-5"
  },
    name: "스타벅스 광주하남점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1627604,
        longitude: 126.8163048
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금| 7:00 - 23:00'
        
      },
      {
         
         content: '토, 일| 8:00 - 23:00'
        
      },
      {
      
         
        title: '전화번호',
        content: '062-959-8679'
      }
         
    ] 
  }, 
   {
    location: "광주광역시 광산구 하남동 용아로 342",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "광산구",
      place: "용아로 342"
  },
    name: "스타벅스 광주산정DT점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.17282,
        longitude: 126.8174936
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금, 토 일| 7:00 - 23:00'
        
      },
      {
      
      
         
        title: '전화번호',
        content: '062-954-3595'
      }
         
    ] 
  }, 
   {
    location: "광주광역시 광산구 신가동 706-1",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "광산구",
      place: "706-1"
  },
    name: "스타벅스 광주신가DT점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1803238,
        longitude: 126.8223689
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금, 토| 7:00 - 23:00'
        
      },
      {
         
         content: '일| 8:00 - 23:00'
        
      },
      {
      
         
        title: '전화번호',
        content: '062-962-6855'
      }
         
    ] 
  }, 
   {
    location: "광주광역시 북구 운암3동 65-11",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "북구",
      place: "65-11"
  },
    name: "스타벅스 광주운암DT점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1780388,
        longitude: 126.8613344
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금, 토, 일| 7:00 - 23:00'
        
     
      },
      {
      
         
        title: '전화번호',
        content: '062-511-8950'
      }
         
    ] 
  }, 
   {
    location: "광주광역시 서구 동천동 하남대로 672-1",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "서구",
      place: "하남대로 672-1"
  },
    name: "스타벅스 광주동림점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1796727,
        longitude: 126.8552512
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금| 7:00 - 23:00'
        
      },
      {
         
         content: '토, 일| 8:00 - 23:00'
        
      },
      {
      
         
        title: '전화번호',
        content: '062-514-3667'
      }
         
    ] 
  }, 
   {
    location: "광주광역시 북구 용봉동 저불로 45",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "북구",
      place: "저불로 45"
  },
    name: "스타벅스 광주용봉점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1810476,
        longitude: 126.8758971
      }
    },
    info: [
    
      {
        title: '운영시간',
        content: '월, 화, 수, 목, 금| 7:00 - 23:00'
        
      },
      {
         
         content: '토, 일| 8:00 - 23:00'
        
      },
      {
      
         
        title: '전화번호',
        content: '062-523-8471'
      }
      ]
   }
]
      
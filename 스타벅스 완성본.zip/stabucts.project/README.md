<p align="Center">
  <img src="https://bixbydevelopers.com/dev/docs-assets/resources/dev-guide/bixby_logo_github-11221940070278028369.png">
  <br/>
  <h1 align="Center">Bixby Hydrogen Find Capsule</h1>
</p>

## Overview

이 캡슐은 광주 스타벅스 검색 캡슐입니다.

## Example flow

```
광주 스타벅스 알려줘

주변 스타벅스 찾아줘
```
---



module.exports = [
  {
    location: "서광주광역시 광천동 932 번지 신세계 백화점 1층 서구 광주광역시 KR울 서초구 바우뫼로12길 73",
    location1:{
      levelOneDiv: "광주광역시",
      levelTwoDiv: "서구",
      place: "바우뫼로12길 73"
  },
    name: "스타벅스 신세계광주점",
    url : "http://kko.to/mcMfbtYjp",
    flag : false,
    call : "tel:02-2058-1351",
    point:{
      point:{
        latitude: 35.1589772,
        longitude: 126.8824801
      }
    },
    info: [
     
      {
        title: '운영시간',
        content: '10시30분~21시'
        
      },
  
      {
        title: '전화번호',
        content: '062-360-1137'
      },
      
    ] 
  },  
  